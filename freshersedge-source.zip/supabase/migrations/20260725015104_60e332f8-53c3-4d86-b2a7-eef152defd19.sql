
CREATE OR REPLACE FUNCTION public.generate_payment_reference()
RETURNS TEXT LANGUAGE plpgsql SET search_path = public AS $$
DECLARE ref TEXT;
BEGIN
  ref := 'FE' || to_char(now(), 'YYMMDD') || upper(substr(md5(random()::text), 1, 6));
  RETURN ref;
END; $$;

REVOKE EXECUTE ON FUNCTION public.generate_payment_reference() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.tg_set_updated_at() FROM PUBLIC, anon, authenticated;
-- has_role stays callable by authenticated (used indirectly by RLS is fine; SECURITY DEFINER needed)
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, app_role) FROM PUBLIC, anon;
