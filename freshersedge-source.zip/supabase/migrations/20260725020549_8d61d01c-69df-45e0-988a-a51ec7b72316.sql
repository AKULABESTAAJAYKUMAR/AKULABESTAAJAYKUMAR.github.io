
DROP POLICY IF EXISTS "anyone can submit contact" ON public.contact_messages;
CREATE POLICY "anyone can submit contact"
ON public.contact_messages
FOR INSERT
TO anon, authenticated
WITH CHECK (
  length(btrim(name)) BETWEEN 1 AND 100
  AND length(btrim(email)) BETWEEN 3 AND 255
  AND email LIKE '%_@_%.__%'
  AND length(btrim(message)) BETWEEN 1 AND 5000
  AND (phone IS NULL OR length(phone) <= 20)
);
