
-- Payments: drop permissive public policies
DROP POLICY IF EXISTS "anyone can create payment" ON public.payments;
DROP POLICY IF EXISTS "anyone can read payments" ON public.payments;
DROP POLICY IF EXISTS "anyone can update screenshot" ON public.payments;

-- Revoke direct table access from anon/authenticated; admin policy + service role remain
REVOKE ALL ON public.payments FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.payments FROM authenticated;
-- keep SELECT grant so admin policy can evaluate for signed-in admins
GRANT SELECT ON public.payments TO authenticated;
GRANT ALL ON public.payments TO service_role;

-- Storage: remove public upload/read policies on payment-screenshots
DROP POLICY IF EXISTS "anyone upload screenshots" ON storage.objects;
DROP POLICY IF EXISTS "anyone read own upload via signed" ON storage.objects;

-- has_role: switch to SECURITY INVOKER so signed-in users no longer execute a DEFINER function.
-- Users can read their own user_roles rows (existing RLS), which is all this function checks.
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path TO 'public'
AS $function$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$function$;
