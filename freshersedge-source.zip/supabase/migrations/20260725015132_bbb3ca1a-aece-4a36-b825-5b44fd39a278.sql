
CREATE POLICY "anyone upload screenshots" ON storage.objects FOR INSERT TO anon, authenticated
WITH CHECK (bucket_id = 'payment-screenshots');

CREATE POLICY "admins view screenshots" ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'payment-screenshots' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "anyone read own upload via signed" ON storage.objects FOR SELECT TO anon, authenticated
USING (bucket_id = 'payment-screenshots');
