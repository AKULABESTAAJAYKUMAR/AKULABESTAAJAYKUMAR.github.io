export type UpiRoute = { upiId: string; bank: string };

// Original UPI IDs from the source screenshot.
export function getUpiForAmount(amount: number): UpiRoute {
  if (amount < 600) return { upiId: "freshersedgee@ybl", bank: "Canara Bank" };
  if (amount < 1000) return { upiId: "jayhelp@ybl", bank: "State Bank of India" };
  if (amount < 2000) return { upiId: "jayicicib@ybl", bank: "ICICI Bank" };
  return { upiId: "jayinter@ybl", bank: "AP Grameena Bank" };
}


export function buildUpiUri(opts: {
  upiId: string;
  name: string;
  amount: number;
  reference: string;
  note?: string;
}): string {
  const params = new URLSearchParams({
    pa: opts.upiId,
    pn: opts.name,
    am: opts.amount.toFixed(2),
    cu: "INR",
    tn: opts.note ?? `FreshersEdge ${opts.reference}`,
    tr: opts.reference,
  });
  return `upi://pay?${params.toString()}`;
}

export const SERVICE_TYPES = [
  "Exam Assistance",
  "Interview Assistance",
  "Coding Assistance",
  "MCQ Guidance",
  "Placement Preparation",
  "Resume Guidance",
] as const;
