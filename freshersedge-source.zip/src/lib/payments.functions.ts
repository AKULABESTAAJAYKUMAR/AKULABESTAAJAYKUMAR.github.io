import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const createSchema = z.object({
  full_name: z.string().trim().min(2).max(100),
  phone: z.string().trim().regex(/^[6-9]\d{9}$/),
  email: z.string().trim().email().max(255),
  service_type: z.string().min(2).max(100),
  amount: z.number().min(100).max(50000),
  upi_id: z.string().min(3).max(100),
});

function genRef() {
  const d = new Date().toISOString().slice(2, 10).replace(/-/g, "");
  return "FE" + d + Math.random().toString(36).slice(2, 8).toUpperCase();
}

export const createPayment = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => createSchema.parse(data))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const reference_number = genRef();
    const { data: row, error } = await supabaseAdmin
      .from("payments")
      .insert({ ...data, reference_number, status: "pending" })
      .select("id, reference_number")
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

const uploadSchema = z.object({
  payment_id: z.string().uuid(),
  reference_number: z.string().min(6).max(64),
  filename: z.string().min(1).max(200),
  content_type: z.string().min(1).max(100),
  // base64 (no data: prefix); limit ~6 MB encoded
  base64: z.string().min(10).max(8_000_000),
});

export const uploadScreenshot = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => uploadSchema.parse(data))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // Verify the payment exists, is pending, and reference matches
    const { data: pay, error: readErr } = await supabaseAdmin
      .from("payments")
      .select("id, status, reference_number")
      .eq("id", data.payment_id)
      .maybeSingle();
    if (readErr) throw new Error(readErr.message);
    if (!pay || pay.reference_number !== data.reference_number) throw new Error("Payment not found");
    if (pay.status !== "pending") throw new Error("Payment already processed");

    const bytes = Buffer.from(data.base64, "base64");
    if (bytes.length > 6 * 1024 * 1024) throw new Error("File too large");
    const ext = (data.filename.split(".").pop() || "png").toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 5) || "png";
    const path = `${data.payment_id}/${Date.now()}.${ext}`;
    const { error: upErr } = await supabaseAdmin.storage
      .from("payment-screenshots")
      .upload(path, bytes, { upsert: true, contentType: data.content_type });
    if (upErr) throw new Error(upErr.message);
    const { error: dbErr } = await supabaseAdmin
      .from("payments")
      .update({ screenshot_url: path })
      .eq("id", data.payment_id);
    if (dbErr) throw new Error(dbErr.message);
    return { ok: true };
  });

export const getPaymentStatus = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => z.object({ reference_number: z.string().min(6).max(64) }).parse(data))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row, error } = await supabaseAdmin
      .from("payments")
      .select("reference_number, status, amount, service_type, full_name")
      .eq("reference_number", data.reference_number)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return row;
  });
