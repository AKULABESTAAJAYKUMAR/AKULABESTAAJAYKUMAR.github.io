import { createServerFn } from "@tanstack/react-start";

// Bootstrap admin: idempotent. If the target email doesn't exist as a user, create it.
// If the user has no admin role, grant it. Safe to call from anywhere/anytime.
export const bootstrapAdmin = createServerFn({ method: "POST" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const email = "freshersedge@gmail.com";
  const password = "Kumar@123";

  // Check if any admin already exists — if yes, skip creation
  const { data: existingAdmins } = await supabaseAdmin.from("user_roles").select("id").eq("role", "admin").limit(1);
  if (existingAdmins && existingAdmins.length > 0) return { ok: true, existed: true };

  // Find user by email; if not, create
  const { data: users } = await supabaseAdmin.auth.admin.listUsers();
  let userId = users?.users?.find((u) => u.email === email)?.id;
  if (!userId) {
    const { data: created, error: createErr } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
    });
    if (createErr || !created.user) throw new Error(createErr?.message ?? "Failed to create admin");
    userId = created.user.id;
  }

  await supabaseAdmin.from("user_roles").insert({ user_id: userId, role: "admin" }).select();
  return { ok: true, created: true };
});
