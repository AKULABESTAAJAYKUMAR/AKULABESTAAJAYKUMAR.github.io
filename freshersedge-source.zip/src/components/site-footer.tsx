import { Link } from "@tanstack/react-router";
import { GraduationCap, Mail, Phone } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t bg-gradient-soft">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid gap-10 md:grid-cols-4">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 font-display font-bold text-lg">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-primary text-primary-foreground">
                <GraduationCap className="h-5 w-5" />
              </span>
              Freshers<span className="text-gradient-primary">Edge</span>
            </div>
            <p className="mt-3 max-w-md text-sm text-muted-foreground">
              Trusted exam & interview assistance for freshers. Fast support, real guidance, transparent pricing.
            </p>
            <div className="mt-4 space-y-1 text-sm text-muted-foreground">
              <a href="mailto:freshersedge@gmail.com" className="flex items-center gap-2 hover:text-foreground">
                <Mail className="h-4 w-4" /> freshersedge@gmail.com
              </a>
              <a href="tel:+917448737207" className="flex items-center gap-2 hover:text-foreground">
                <Phone className="h-4 w-4" /> +91 74487 37207
              </a>
            </div>
          </div>
          <div>
            <h4 className="font-semibold text-sm mb-3">Services</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link to="/exam-assistance" className="hover:text-foreground">Exam Assistance</Link></li>
              <li><Link to="/interview-assistance" className="hover:text-foreground">Interview Assistance</Link></li>
              <li><Link to="/payment" className="hover:text-foreground">Make Payment</Link></li>
              <li><Link to="/contact" className="hover:text-foreground">Contact</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-sm mb-3">Legal</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link to="/privacy" className="hover:text-foreground">Privacy Policy</Link></li>
              <li><Link to="/refund" className="hover:text-foreground">Refund Policy</Link></li>
              <li><Link to="/terms" className="hover:text-foreground">Terms & Conditions</Link></li>
              <li><Link to="/admin/login" className="hover:text-foreground">Admin</Link></li>
            </ul>
          </div>
        </div>
        <div className="mt-10 pt-6 border-t text-xs text-muted-foreground flex flex-wrap items-center justify-between gap-2">
          <span>© {new Date().getFullYear()} FreshersEdge. All rights reserved.</span>
          <span>Made with care for placement aspirants.</span>
        </div>
      </div>
    </footer>
  );
}
