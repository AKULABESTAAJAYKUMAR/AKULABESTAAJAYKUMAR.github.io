import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Mail, Phone, MessageCircle, MapPin, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — FreshersEdge" },
      { name: "description", content: "Get in touch with FreshersEdge for exam and interview assistance. WhatsApp, email or the form below." },
      { property: "og:title", content: "Contact FreshersEdge" },
      { property: "og:description", content: "Reach us on WhatsApp, email, or the contact form." },
    ],
  }),
  component: ContactPage,
});

const schema = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(255),
  phone: z.string().trim().max(20).optional().or(z.literal("")),
  message: z.string().trim().min(5).max(2000),
});

function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });
  const [sending, setSending] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    setSending(true);
    const { error } = await supabase.from("contact_messages").insert(parsed.data);
    setSending(false);
    if (error) { toast.error("Could not send. Try WhatsApp."); return; }
    toast.success("Message sent — we'll reply shortly.");
    setForm({ name: "", email: "", phone: "", message: "" });
  }

  return (
    <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-16">
      <div className="text-center max-w-2xl mx-auto">
        <div className="text-xs font-semibold uppercase tracking-wider text-primary">Contact</div>
        <h1 className="mt-2 text-4xl md:text-5xl font-bold">Let's talk</h1>
        <p className="mt-3 text-muted-foreground">Fastest reply is on WhatsApp. Or drop us a note here.</p>
      </div>

      <div className="mt-12 grid lg:grid-cols-5 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <ContactCard icon={MessageCircle} title="WhatsApp" value="+91 74487 37207" href="https://wa.me/917448737207" />
          <ContactCard icon={Mail} title="Email" value="freshersedge@gmail.com" href="mailto:freshersedge@gmail.com" />
          <ContactCard icon={Phone} title="Phone" value="+91 74487 37207" href="tel:+917448737207" />
          <ContactCard icon={MapPin} title="Hours" value="24×7 Support" />
        </div>
        <form onSubmit={submit} className="lg:col-span-3 rounded-3xl border bg-card shadow-elegant p-6 md:p-8 space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">Name</label>
              <input className="input mt-1.5" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            <div>
              <label className="text-sm font-medium">Email</label>
              <input type="email" className="input mt-1.5" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
          </div>
          <div>
            <label className="text-sm font-medium">Phone (optional)</label>
            <input className="input mt-1.5" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </div>
          <div>
            <label className="text-sm font-medium">Message</label>
            <textarea rows={5} className="input mt-1.5" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
          </div>
          <button disabled={sending} className="w-full inline-flex items-center justify-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-elegant hover:shadow-premium transition disabled:opacity-60">
            {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send message"}
          </button>
        </form>
      </div>
    </div>
  );
}

function ContactCard({ icon: Icon, title, value, href }: { icon: any; title: string; value: string; href?: string }) {
  const Cmp: any = href ? "a" : "div";
  return (
    <Cmp href={href} target={href?.startsWith("http") ? "_blank" : undefined} rel="noreferrer" className="block rounded-2xl border bg-card p-5 hover:shadow-elegant transition">
      <div className="flex items-center gap-4">
        <div className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-primary text-primary-foreground">
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <div className="text-xs text-muted-foreground">{title}</div>
          <div className="font-semibold">{value}</div>
        </div>
      </div>
    </Cmp>
  );
}
