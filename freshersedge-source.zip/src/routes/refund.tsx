import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/refund")({
  head: () => ({
    meta: [
      { title: "Refund Policy — FreshersEdge" },
      { name: "description", content: "Refund policy for FreshersEdge exam and interview assistance services." },
      { property: "og:title", content: "Refund Policy — FreshersEdge" },
      { property: "og:description", content: "When and how refunds are processed." },
    ],
  }),
  component: () => (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-16">
      <div className="text-center">
        <div className="text-xs font-semibold uppercase tracking-wider text-primary">Legal</div>
        <h1 className="mt-2 text-4xl md:text-5xl font-bold">Refund Policy</h1>
      </div>
      <div className="mt-10 rounded-3xl border bg-card shadow-elegant p-8 space-y-4 text-sm text-muted-foreground">
        <p><strong className="text-foreground">Eligibility:</strong> Refunds are considered when we fail to deliver the agreed service, or when a payment is duplicated.</p>
        <p><strong className="text-foreground">Non-refundable:</strong> Once a session has begun, or once instructions have been delivered, the fee is non-refundable.</p>
        <p><strong className="text-foreground">Timeline:</strong> Approved refunds are processed within 5–7 business days to the same UPI account.</p>
        <p><strong className="text-foreground">How to request:</strong> Email freshersedge@gmail.com with your reference number and reason. Every request is reviewed by a human within 24 hours.</p>
      </div>
    </div>
  ),
});
