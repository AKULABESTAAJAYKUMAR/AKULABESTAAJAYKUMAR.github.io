import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { CheckCircle2, ArrowRight, BookOpen } from "lucide-react";
import examImg from "@/assets/exam-banner.jpg";

export const Route = createFileRoute("/exam-assistance")({
  head: () => ({
    meta: [
      { title: "Exam Assistance — FreshersEdge" },
      { name: "description", content: "Real-time help during online exams, MCQs, and technical assessments. Read the terms and get started." },
      { property: "og:title", content: "Exam Assistance — FreshersEdge" },
      { property: "og:description", content: "Real-time help during online exams and technical assessments." },
    ],
  }),
  component: ExamPage,
});

const instructions = [
  "Share your exam schedule with us at least 30 minutes before it starts.",
  "Provide the required login details privately over WhatsApp.",
  "Ensure a stable internet connection during the entire duration.",
  "Do not switch tabs excessively — proctoring systems may flag it.",
  "Complete payment before the session begins; confirmation is instant.",
  "Our mentors will guide you in real-time via a private channel.",
  "Any misuse (public sharing of credentials, cheating others) will be rejected.",
];

function ExamPage() {
  const [agreed, setAgreed] = useState(false);
  const navigate = useNavigate();
  return (
    <>
      <section className="relative">
        <div className="absolute inset-0 -z-10 bg-gradient-soft" />
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid lg:grid-cols-2 gap-10 items-center">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full bg-accent px-3 py-1 text-xs font-medium">
                <BookOpen className="h-3.5 w-3.5" /> Exam Assistance
              </div>
              <h1 className="mt-4 text-4xl md:text-5xl font-bold">Focused help when it matters most</h1>
              <p className="mt-4 text-muted-foreground text-lg">
                Live guidance for online exams, MCQ tests, and technical assessments. Read the instructions carefully before proceeding.
              </p>
            </div>
            <div className="rounded-3xl overflow-hidden shadow-premium border">
              <img src={examImg} alt="Exam preparation" width={1600} height={900} loading="lazy" className="w-full h-auto" />
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="rounded-3xl border bg-card shadow-elegant p-8">
          <h2 className="text-2xl font-bold">Instructions</h2>
          <ul className="mt-6 space-y-3">
            {instructions.map((line, i) => (
              <li key={i} className="flex gap-3">
                <CheckCircle2 className="h-5 w-5 mt-0.5 shrink-0 text-primary" />
                <span className="text-sm leading-relaxed">{line}</span>
              </li>
            ))}
          </ul>

          <label className="mt-8 flex items-start gap-3 cursor-pointer p-4 rounded-2xl bg-accent/50 border">
            <input type="checkbox" checked={agreed} onChange={(e) => setAgreed(e.target.checked)} className="mt-1 h-4 w-4 accent-primary" />
            <span className="text-sm">
              I have read and agree to the <Link to="/terms" className="text-primary underline">Terms & Conditions</Link>, <Link to="/refund" className="text-primary underline">Refund Policy</Link> and <Link to="/privacy" className="text-primary underline">Privacy Policy</Link>.
            </span>
          </label>

          <button
            disabled={!agreed}
            onClick={() => navigate({ to: "/payment", search: { service: "Exam Assistance" } })}
            className="mt-6 w-full inline-flex items-center justify-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-elegant enabled:hover:shadow-premium transition disabled:opacity-40 disabled:cursor-not-allowed"
          >
            Proceed to Payment <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </section>
    </>
  );
}
