import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — FreshersEdge" },
      { name: "description", content: "How FreshersEdge collects, uses and protects your personal information." },
      { property: "og:title", content: "Privacy Policy — FreshersEdge" },
      { property: "og:description", content: "How we handle your personal data." },
    ],
  }),
  component: () => <LegalLayout title="Privacy Policy" updated="July 2026">
    <p>We collect only the information required to deliver our services: your name, phone, email, service type and payment details.</p>
    <h2>Data we collect</h2>
    <ul><li>Contact details you submit</li><li>Payment reference and screenshot (if uploaded)</li><li>Messages you send us</li></ul>
    <h2>How we use it</h2>
    <p>To fulfil the service you paid for, verify payments, and communicate about your request. We do not sell your data to third parties.</p>
    <h2>Security</h2>
    <p>All data is stored on encrypted servers with strict access control. Screenshots are visible only to authorised admins.</p>
    <h2>Your rights</h2>
    <p>You can request deletion of your data any time by writing to freshersedge@gmail.com.</p>
  </LegalLayout>,
});

function LegalLayout({ title, updated, children }: { title: string; updated: string; children: React.ReactNode }) {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-16">
      <div className="text-center">
        <div className="text-xs font-semibold uppercase tracking-wider text-primary">Legal</div>
        <h1 className="mt-2 text-4xl md:text-5xl font-bold">{title}</h1>
        <p className="mt-2 text-sm text-muted-foreground">Last updated: {updated}</p>
      </div>
      <article className="prose prose-slate mt-10 rounded-3xl border bg-card shadow-elegant p-8 [&>h2]:mt-6 [&>h2]:text-lg [&>h2]:font-semibold [&>p]:mt-2 [&>p]:text-sm [&>p]:text-muted-foreground [&>ul]:mt-2 [&>ul]:text-sm [&>ul]:text-muted-foreground [&>ul]:list-disc [&>ul]:pl-6 [&>ul>li]:mt-1">
        {children}
      </article>
    </div>
  );
}
