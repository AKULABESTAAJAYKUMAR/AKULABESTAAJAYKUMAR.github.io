import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms & Conditions — FreshersEdge" },
      { name: "description", content: "Terms of use for FreshersEdge services." },
      { property: "og:title", content: "Terms & Conditions — FreshersEdge" },
      { property: "og:description", content: "Terms of use for FreshersEdge services." },
    ],
  }),
  component: () => (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-16">
      <div className="text-center">
        <div className="text-xs font-semibold uppercase tracking-wider text-primary">Legal</div>
        <h1 className="mt-2 text-4xl md:text-5xl font-bold">Terms & Conditions</h1>
      </div>
      <div className="mt-10 rounded-3xl border bg-card shadow-elegant p-8 space-y-4 text-sm text-muted-foreground">
        <p>By using FreshersEdge you agree to these terms. Services are provided as-is with best-effort delivery.</p>
        <p><strong className="text-foreground">Fair use:</strong> Services are for the paying user only. Sharing credentials or misusing our channel results in immediate termination.</p>
        <p><strong className="text-foreground">Guarantee:</strong> We commit to best-effort assistance. Final outcomes depend on your performance and employer decisions.</p>
        <p><strong className="text-foreground">Liability:</strong> Our liability is limited to the amount paid for the specific service.</p>
        <p><strong className="text-foreground">Jurisdiction:</strong> Governed by the laws of India.</p>
      </div>
    </div>
  ),
});
