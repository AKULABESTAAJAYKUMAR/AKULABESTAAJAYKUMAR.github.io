import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  LogOut, Search, Download, Filter, CheckCircle2, XCircle, Clock,
  Users, IndianRupee, TrendingUp, FileImage, Loader2, GraduationCap,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { SERVICE_TYPES } from "@/lib/upi";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/admin/dashboard")({
  head: () => ({
    meta: [
      { title: "Admin Dashboard — FreshersEdge" },
      { name: "description", content: "Manage payments and verify submissions." },
      { property: "og:title", content: "Admin Dashboard" },
      { property: "og:description", content: "Admin dashboard." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Dashboard,
});

type Payment = {
  id: string;
  reference_number: string;
  full_name: string;
  phone: string;
  email: string;
  service_type: string;
  amount: number;
  upi_id: string;
  screenshot_url: string | null;
  status: string;
  admin_notes: string | null;
  created_at: string;
};

function Dashboard() {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState("");
  const [service, setService] = useState<string>("all");
  const [status, setStatus] = useState<string>("all");
  const [screenshotUrl, setScreenshotUrl] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    async function guard() {
      const { data } = await supabase.auth.getSession();
      if (!data.session) { navigate({ to: "/admin/login" }); return; }
      // Verify admin role
      const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", data.session.user.id);
      if (!roles?.some((r) => r.role === "admin")) {
        toast.error("Not an admin account");
        await supabase.auth.signOut();
        navigate({ to: "/admin/login" });
        return;
      }
      if (mounted) { setChecking(false); load(); }
    }
    guard();
    return () => { mounted = false; };
  }, [navigate]);

  async function load() {
    setLoading(true);
    const { data, error } = await supabase.from("payments").select("*").order("created_at", { ascending: false }).limit(500);
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    setPayments((data as Payment[]) ?? []);
  }

  async function updateStatus(id: string, status: "verified" | "rejected") {
    const { error } = await supabase.from("payments").update({ status }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success(`Marked as ${status}`);
    load();
  }

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/admin/login" });
  }

  async function viewScreenshot(path: string) {
    const { data, error } = await supabase.storage.from("payment-screenshots").createSignedUrl(path, 300);
    if (error || !data) { toast.error("Could not load screenshot"); return; }
    setScreenshotUrl(data.signedUrl);
  }

  const filtered = useMemo(() => {
    return payments.filter((p) => {
      if (service !== "all" && p.service_type !== service) return false;
      if (status !== "all" && p.status !== status) return false;
      if (query) {
        const q = query.toLowerCase();
        return [p.full_name, p.email, p.phone, p.reference_number].some((v) => v.toLowerCase().includes(q));
      }
      return true;
    });
  }, [payments, service, status, query]);

  const stats = useMemo(() => {
    const today = new Date().toDateString();
    return {
      total: new Set(payments.map((p) => p.email)).size,
      todayPayments: payments.filter((p) => new Date(p.created_at).toDateString() === today).length,
      pending: payments.filter((p) => p.status === "pending").length,
      verified: payments.filter((p) => p.status === "verified").length,
      rejected: payments.filter((p) => p.status === "rejected").length,
      revenue: payments.filter((p) => p.status === "verified").reduce((s, p) => s + Number(p.amount), 0),
    };
  }, [payments]);

  function exportCsv() {
    const rows = [
      ["Reference", "Name", "Phone", "Email", "Service", "Amount", "UPI ID", "Status", "Created"],
      ...filtered.map((p) => [
        p.reference_number, p.full_name, p.phone, p.email, p.service_type,
        String(p.amount), p.upi_id, p.status, new Date(p.created_at).toISOString(),
      ]),
    ];
    const csv = rows.map((r) => r.map((c) => `"${(c ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `payments-${Date.now()}.csv`; a.click();
    URL.revokeObjectURL(url);
  }

  if (checking) {
    return <div className="min-h-screen grid place-items-center"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>;
  }

  return (
    <div className="min-h-screen bg-gradient-soft">
      {/* Top bar */}
      <header className="glass border-b sticky top-0 z-40">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center gap-2 font-display font-bold">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-primary text-primary-foreground"><GraduationCap className="h-4 w-4" /></span>
            FreshersEdge <span className="ml-2 text-xs font-normal text-muted-foreground">Admin</span>
          </Link>
          <button onClick={signOut} className="inline-flex items-center gap-2 rounded-full border bg-card px-4 py-2 text-sm hover:bg-accent">
            <LogOut className="h-4 w-4" /> Sign out
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-sm text-muted-foreground">Overview of all payment submissions.</p>
        </div>

        {/* Stats */}
        <div className="grid gap-4 grid-cols-2 md:grid-cols-3 lg:grid-cols-6">
          <StatCard icon={Users} label="Unique Users" value={stats.total} color="text-primary" />
          <StatCard icon={TrendingUp} label="Today" value={stats.todayPayments} color="text-primary" />
          <StatCard icon={Clock} label="Pending" value={stats.pending} color="text-warning" />
          <StatCard icon={CheckCircle2} label="Verified" value={stats.verified} color="text-success" />
          <StatCard icon={XCircle} label="Rejected" value={stats.rejected} color="text-destructive" />
          <StatCard icon={IndianRupee} label="Revenue" value={`₹${stats.revenue.toFixed(0)}`} color="text-primary" />
        </div>

        {/* Filters */}
        <div className="rounded-2xl border bg-card p-4 flex flex-wrap gap-3 items-center">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input className="input pl-9" placeholder="Search name, email, phone, reference…" value={query} onChange={(e) => setQuery(e.target.value)} />
          </div>
          <div className="relative">
            <Filter className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <select className="input pl-9 pr-8" value={service} onChange={(e) => setService(e.target.value)}>
              <option value="all">All services</option>
              {SERVICE_TYPES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <select className="input w-auto" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="all">All statuses</option>
            <option value="pending">Pending</option>
            <option value="verified">Verified</option>
            <option value="rejected">Rejected</option>
          </select>
          <button onClick={exportCsv} className="inline-flex items-center gap-2 rounded-full bg-gradient-primary px-4 py-2 text-sm font-semibold text-primary-foreground">
            <Download className="h-4 w-4" /> CSV
          </button>
        </div>

        {/* Table */}
        <div className="rounded-2xl border bg-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-accent/50">
                <tr className="text-left text-xs uppercase tracking-wider text-muted-foreground">
                  <th className="px-4 py-3">Reference</th>
                  <th className="px-4 py-3">User</th>
                  <th className="px-4 py-3">Service</th>
                  <th className="px-4 py-3">Amount</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Screenshot</th>
                  <th className="px-4 py-3">Date</th>
                  <th className="px-4 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {loading && (
                  <tr><td colSpan={8} className="px-4 py-12 text-center"><Loader2 className="h-5 w-5 animate-spin mx-auto text-primary" /></td></tr>
                )}
                {!loading && filtered.length === 0 && (
                  <tr><td colSpan={8} className="px-4 py-12 text-center text-muted-foreground">No payments found.</td></tr>
                )}
                {filtered.map((p) => (
                  <tr key={p.id} className="hover:bg-accent/30">
                    <td className="px-4 py-3 font-mono text-xs">{p.reference_number}</td>
                    <td className="px-4 py-3">
                      <div className="font-medium">{p.full_name}</div>
                      <div className="text-xs text-muted-foreground">{p.email} · {p.phone}</div>
                    </td>
                    <td className="px-4 py-3">{p.service_type}</td>
                    <td className="px-4 py-3 font-semibold">₹{Number(p.amount).toFixed(0)}</td>
                    <td className="px-4 py-3"><StatusBadge status={p.status} /></td>
                    <td className="px-4 py-3">
                      {p.screenshot_url ? (
                        <button onClick={() => viewScreenshot(p.screenshot_url!)} className="inline-flex items-center gap-1 text-primary text-xs hover:underline">
                          <FileImage className="h-4 w-4" /> View
                        </button>
                      ) : <span className="text-xs text-muted-foreground">—</span>}
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{new Date(p.created_at).toLocaleDateString()}</td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-1">
                        <button onClick={() => updateStatus(p.id, "verified")} className="p-1.5 rounded-lg text-success hover:bg-success/10" title="Approve">
                          <CheckCircle2 className="h-4 w-4" />
                        </button>
                        <button onClick={() => updateStatus(p.id, "rejected")} className="p-1.5 rounded-lg text-destructive hover:bg-destructive/10" title="Reject">
                          <XCircle className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      {screenshotUrl && (
        <div onClick={() => setScreenshotUrl(null)} className="fixed inset-0 z-50 bg-black/70 backdrop-blur grid place-items-center p-4">
          <img src={screenshotUrl} alt="Payment screenshot" className="max-h-[90vh] max-w-full rounded-2xl shadow-premium" />
        </div>
      )}
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }: { icon: any; label: string; value: number | string; color: string }) {
  return (
    <div className="rounded-2xl border bg-card p-4">
      <Icon className={cn("h-5 w-5", color)} />
      <div className="mt-2 text-2xl font-bold">{value}</div>
      <div className="text-xs text-muted-foreground">{label}</div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    pending: "bg-warning/15 text-warning ring-warning/30",
    verified: "bg-success/15 text-success ring-success/30",
    rejected: "bg-destructive/15 text-destructive ring-destructive/30",
  };
  return <span className={cn("inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ring-1", map[status] ?? "bg-accent")}>{status}</span>;
}
