import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { CheckCircle2, ArrowRight, Briefcase } from "lucide-react";
import banner from "@/assets/interview-banner.jpg";

export const Route = createFileRoute("/interview-assistance")({
  head: () => ({
    meta: [
      { title: "Interview Assistance — FreshersEdge" },
      { name: "description", content: "Live technical and HR interview support. Confidence-building sessions, real answers, real results." },
      { property: "og:title", content: "Interview Assistance — FreshersEdge" },
      { property: "og:description", content: "Live technical and HR interview support with experienced mentors." },
    ],
  }),
  component: InterviewPage,
});

const instructions = [
  "Share your interview slot and JD 1 hour in advance.",
  "Test your microphone, camera and internet connection beforehand.",
  "Keep a second device ready for private discreet assistance.",
  "Answer confidently — mentors will guide you on structure and phrasing.",
  "Payment must be completed before the interview begins.",
  "Do not share our channel credentials with third parties.",
  "Post-interview, share the outcome so we can iterate for the next round.",
];

function InterviewPage() {
  const [agreed, setAgreed] = useState(false);
  const navigate = useNavigate();
  return (
    <>
      <section className="relative">
        <div className="absolute inset-0 -z-10 bg-gradient-soft" />
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid lg:grid-cols-2 gap-10 items-center">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full bg-accent px-3 py-1 text-xs font-medium">
                <Briefcase className="h-3.5 w-3.5" /> Interview Assistance
              </div>
              <h1 className="mt-4 text-4xl md:text-5xl font-bold">Walk in ready. Walk out with the offer.</h1>
              <p className="mt-4 text-muted-foreground text-lg">
                Live technical + HR interview support tailored to your company and role.
              </p>
            </div>
            <div className="rounded-3xl overflow-hidden shadow-premium border">
              <img src={banner} alt="Interview" width={1600} height={900} loading="lazy" className="w-full h-auto" />
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="rounded-3xl border bg-card shadow-elegant p-8">
          <h2 className="text-2xl font-bold">Instructions</h2>
          <ul className="mt-6 space-y-3">
            {instructions.map((line, i) => (
              <li key={i} className="flex gap-3">
                <CheckCircle2 className="h-5 w-5 mt-0.5 shrink-0 text-primary" />
                <span className="text-sm leading-relaxed">{line}</span>
              </li>
            ))}
          </ul>

          <label className="mt-8 flex items-start gap-3 cursor-pointer p-4 rounded-2xl bg-accent/50 border">
            <input type="checkbox" checked={agreed} onChange={(e) => setAgreed(e.target.checked)} className="mt-1 h-4 w-4 accent-primary" />
            <span className="text-sm">
              I have read and agree to the <Link to="/terms" className="text-primary underline">Terms</Link>, <Link to="/refund" className="text-primary underline">Refund</Link> and <Link to="/privacy" className="text-primary underline">Privacy</Link> policies.
            </span>
          </label>

          <button
            disabled={!agreed}
            onClick={() => navigate({ to: "/payment", search: { service: "Interview Assistance" } })}
            className="mt-6 w-full inline-flex items-center justify-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-elegant enabled:hover:shadow-premium transition disabled:opacity-40 disabled:cursor-not-allowed"
          >
            Proceed to Payment <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </section>
    </>
  );
}
