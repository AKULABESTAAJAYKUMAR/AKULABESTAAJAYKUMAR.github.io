import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Lock, Loader2, GraduationCap, KeyRound } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { bootstrapAdmin } from "@/lib/admin.functions";

export const Route = createFileRoute("/admin/login")({
  head: () => ({
    meta: [
      { title: "Admin Login — FreshersEdge" },
      { name: "description", content: "Secure admin access." },
      { property: "og:title", content: "Admin Login" },
      { property: "og:description", content: "Admin access." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: LoginPage,
});

const schema = z.object({
  email: z.string().trim().email(),
  password: z.string().min(6),
});

function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Bootstrap admin account once (idempotent server-side)
    bootstrapAdmin().catch(() => {});
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/admin/dashboard" });
    });
  }, [navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = schema.safeParse({ email, password });
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword(parsed.data);
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Signed in");
    navigate({ to: "/admin/dashboard" });
  }

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="hidden lg:flex relative flex-col justify-between p-10 text-primary-foreground overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-gradient-hero" />
        <div className="absolute inset-0 -z-10" style={{ backgroundImage: "var(--gradient-glow)" }} />
        <Link to="/" className="inline-flex items-center gap-2 font-display font-bold text-lg">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-white/20 backdrop-blur">
            <GraduationCap className="h-5 w-5" />
          </span>
          FreshersEdge
        </Link>
        <div>
          <h1 className="text-4xl font-bold">Admin Console</h1>
          <p className="mt-3 max-w-md text-primary-foreground/80">Manage payments, verify submissions, and keep the team moving.</p>
        </div>
        <div className="text-xs text-primary-foreground/60">Restricted access • authorised personnel only</div>
      </div>
      <div className="flex items-center justify-center p-6 md:p-10 bg-gradient-soft">
        <form onSubmit={submit} className="w-full max-w-md rounded-3xl border bg-card shadow-premium p-8 space-y-5">
          <div className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-primary text-primary-foreground shadow-glow-primary">
            <Lock className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Admin Sign In</h2>
            <p className="mt-1 text-sm text-muted-foreground">Enter your admin credentials to continue.</p>
          </div>
          <div>
            <label className="text-sm font-medium">Email</label>
            <input type="email" className="input mt-1.5" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
          </div>
          <div>
            <label className="text-sm font-medium">Password</label>
            <div className="relative mt-1.5">
              <KeyRound className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input type="password" className="input pl-9" value={password} onChange={(e) => setPassword(e.target.value)} />
            </div>
          </div>
          <button disabled={loading} className="w-full inline-flex items-center justify-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-elegant hover:shadow-premium transition disabled:opacity-60">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Sign in"}
          </button>
          <p className="text-xs text-center text-muted-foreground">
            <Link to="/" className="hover:text-foreground">← Back to site</Link>
          </p>
        </form>
      </div>
    </div>
  );
}
