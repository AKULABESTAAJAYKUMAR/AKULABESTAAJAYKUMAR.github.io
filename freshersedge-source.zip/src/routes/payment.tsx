import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { z } from "zod";
import QRCode from "qrcode";
import { toast } from "sonner";
import {
  User, CreditCard, ShieldCheck, Copy, Check, Upload, Loader2, ArrowRight, Smartphone,
} from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { SERVICE_TYPES, getUpiForAmount, buildUpiUri } from "@/lib/upi";
import { createPayment, uploadScreenshot as uploadScreenshotFn } from "@/lib/payments.functions";
import { cn } from "@/lib/utils";

const searchSchema = z.object({ service: z.string().optional() });

export const Route = createFileRoute("/payment")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Payment Portal — FreshersEdge" },
      { name: "description", content: "Secure UPI payment for FreshersEdge services. GPay, PhonePe, Paytm, BHIM supported." },
      { property: "og:title", content: "Payment Portal — FreshersEdge" },
      { property: "og:description", content: "Secure UPI payment portal." },
    ],
  }),
  component: PaymentPage,
});

const detailsSchema = z.object({
  full_name: z.string().trim().min(2, "Enter your full name").max(100),
  phone: z.string().trim().regex(/^[6-9]\d{9}$/, "Enter a valid 10-digit Indian mobile"),
  email: z.string().trim().email("Enter a valid email").max(255),
  service_type: z.enum(SERVICE_TYPES as unknown as [string, ...string[]]),
  amount: z.number().min(100, "Minimum ₹100").max(50000, "Maximum ₹50,000"),
});

type Details = z.infer<typeof detailsSchema>;

function PaymentPage() {
  const { service } = Route.useSearch();
  const navigate = useNavigate();
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [details, setDetails] = useState<Partial<Details>>({
    service_type: (service as Details["service_type"]) ?? "Exam Assistance",
    amount: 500,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [paymentId, setPaymentId] = useState<string | null>(null);
  const [referenceNumber, setReferenceNumber] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState<string>("");
  const [copied, setCopied] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [finalizing, setFinalizing] = useState(false);
  const createPaymentFn = useServerFn(createPayment);
  const uploadScreenshotServerFn = useServerFn(uploadScreenshotFn);

  const route = useMemo(() => getUpiForAmount(details.amount ?? 0), [details.amount]);
  const upiUri = useMemo(() => {
    if (!referenceNumber || !details.amount || !details.full_name) return "";
    return buildUpiUri({
      upiId: route.upiId,
      name: "FreshersEdge",
      amount: details.amount,
      reference: referenceNumber,
    });
  }, [referenceNumber, details.amount, details.full_name, route]);

  useEffect(() => {
    if (!upiUri) return;
    QRCode.toDataURL(upiUri, { width: 320, margin: 1, color: { dark: "#1e2a5e", light: "#ffffff" } })
      .then(setQrDataUrl)
      .catch(() => {});
  }, [upiUri]);

  async function submitDetails(e: React.FormEvent) {
    e.preventDefault();
    const parsed = detailsSchema.safeParse({
      ...details,
      amount: Number(details.amount),
    });
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      parsed.error.issues.forEach((i) => { errs[i.path[0] as string] = i.message; });
      setErrors(errs);
      return;
    }
    setErrors({});
    setCreating(true);
    try {
      // generate reference client-side
      const ref = "FE" + new Date().toISOString().slice(2, 10).replace(/-/g, "") + Math.random().toString(36).slice(2, 8).toUpperCase();
      const upi = getUpiForAmount(parsed.data.amount).upiId;
      const { data, error } = await supabase
        .from("payments")
        .insert({
          reference_number: ref,
          full_name: parsed.data.full_name,
          phone: parsed.data.phone,
          email: parsed.data.email,
          service_type: parsed.data.service_type,
          amount: parsed.data.amount,
          upi_id: upi,
          status: "pending",
        })
        .select("id, reference_number")
        .single();
      if (error) throw error;
      setPaymentId(data.id);
      setReferenceNumber(data.reference_number);
      setStep(2);
    } catch (err) {
      toast.error("Could not start payment. Please try again.");
      console.error(err);
    } finally {
      setCreating(false);
    }
  }

  async function uploadScreenshot(file: File) {
    if (!paymentId) return;
    setUploading(true);
    try {
      const ext = file.name.split(".").pop() || "png";
      const path = `${paymentId}/${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("payment-screenshots").upload(path, file, { upsert: true });
      if (upErr) throw upErr;
      const { error: dbErr } = await supabase.from("payments").update({ screenshot_url: path }).eq("id", paymentId);
      if (dbErr) throw dbErr;
      toast.success("Screenshot uploaded");
    } catch (err) {
      console.error(err);
      toast.error("Upload failed. You can still confirm.");
    } finally {
      setUploading(false);
    }
  }

  async function finalize() {
    setFinalizing(true);
    // small delay for UX
    setTimeout(() => {
      navigate({ to: "/payment-success", search: { ref: referenceNumber! } });
    }, 400);
  }

  return (
    <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-12 md:py-16">
      <div className="text-center mb-10">
        <h1 className="text-3xl md:text-4xl font-bold">Payment Portal</h1>
        <p className="mt-2 text-muted-foreground">Secure, direct UPI payment. Fully verified before your session begins.</p>
      </div>

      <Stepper step={step} />

      {step === 1 && (
        <form onSubmit={submitDetails} className="mt-10 rounded-3xl border bg-card shadow-elegant p-6 md:p-8 space-y-5">
          <h2 className="text-xl font-semibold">Your details</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <Field label="Full name" error={errors.full_name}>
              <input className="input" value={details.full_name ?? ""} onChange={(e) => setDetails({ ...details, full_name: e.target.value })} placeholder="Jane Sharma" />
            </Field>
            <Field label="Phone" error={errors.phone}>
              <input className="input" value={details.phone ?? ""} onChange={(e) => setDetails({ ...details, phone: e.target.value })} placeholder="9876543210" maxLength={10} />
            </Field>
            <Field label="Email" error={errors.email}>
              <input className="input" type="email" value={details.email ?? ""} onChange={(e) => setDetails({ ...details, email: e.target.value })} placeholder="you@email.com" />
            </Field>
            <Field label="Service" error={errors.service_type}>
              <select className="input" value={details.service_type ?? ""} onChange={(e) => setDetails({ ...details, service_type: e.target.value as Details["service_type"] })}>
                {SERVICE_TYPES.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </Field>
            <Field label="Amount (₹)" error={errors.amount} className="md:col-span-2">
              <input className="input" type="number" min={100} step={50} value={details.amount ?? ""} onChange={(e) => setDetails({ ...details, amount: Number(e.target.value) })} />
              <p className="mt-2 text-xs text-muted-foreground">Will route via <span className="font-semibold text-foreground">{route.bank}</span> ({route.upiId})</p>
            </Field>
          </div>
          <button disabled={creating} className="w-full inline-flex items-center justify-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-elegant hover:shadow-premium transition disabled:opacity-60">
            {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <>Continue to payment <ArrowRight className="h-4 w-4" /></>}
          </button>
        </form>
      )}

      {step === 2 && referenceNumber && (
        <div className="mt-10 grid md:grid-cols-2 gap-6">
          <div className="rounded-3xl border bg-card shadow-elegant p-6 md:p-8">
            <h2 className="text-xl font-semibold">Scan to pay</h2>
            <p className="mt-1 text-sm text-muted-foreground">Open any UPI app and scan the QR.</p>
            <div className="mt-6 grid place-items-center">
              {qrDataUrl ? (
                <img src={qrDataUrl} alt="UPI QR" className="rounded-2xl border shadow-sm bg-white p-3" width={280} height={280} />
              ) : (
                <div className="h-[280px] w-[280px] rounded-2xl bg-accent animate-pulse" />
              )}
            </div>
            <div className="mt-6 space-y-3">
              <InfoRow label="UPI ID" value={route.upiId} onCopy={() => { navigator.clipboard.writeText(route.upiId); setCopied(true); setTimeout(() => setCopied(false), 1500); }} copied={copied} />
              <InfoRow label="Amount" value={`₹${details.amount?.toFixed(2)}`} />
              <InfoRow label="Bank" value={route.bank} />
              <InfoRow label="Reference" value={referenceNumber} />
            </div>
          </div>

          <div className="rounded-3xl border bg-card shadow-elegant p-6 md:p-8 flex flex-col">
            <h2 className="text-xl font-semibold">Open payment app</h2>
            <p className="mt-1 text-sm text-muted-foreground">On mobile, tap to open directly.</p>
            <div className="mt-5 grid grid-cols-2 gap-3">
              {[
                { name: "Google Pay", url: upiUri },
                { name: "PhonePe", url: upiUri.replace("upi://", "phonepe://") },
                { name: "Paytm", url: upiUri.replace("upi://", "paytmmp://") },
                { name: "BHIM / Any UPI", url: upiUri },
              ].map((app) => (
                <a
                  key={app.name}
                  href={app.url}
                  className="group inline-flex items-center gap-2 rounded-2xl border bg-card px-4 py-3 text-sm font-medium hover:border-primary hover:bg-accent transition"
                >
                  <Smartphone className="h-4 w-4 text-primary" />
                  {app.name}
                </a>
              ))}
            </div>

            <div className="mt-6 rounded-2xl border-dashed border-2 border-border p-5 text-center">
              <p className="text-sm font-medium">Optional: upload screenshot</p>
              <p className="mt-1 text-xs text-muted-foreground">Speeds up verification.</p>
              <label className="mt-4 inline-flex items-center justify-center gap-2 rounded-full bg-accent px-4 py-2 text-sm font-medium cursor-pointer hover:bg-primary hover:text-primary-foreground transition">
                {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                {uploading ? "Uploading..." : "Choose file"}
                <input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) uploadScreenshot(f); }} />
              </label>
            </div>

            <button onClick={finalize} disabled={finalizing} className="mt-auto pt-6">
              <span className="w-full inline-flex items-center justify-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-elegant hover:shadow-premium transition">
                {finalizing ? <Loader2 className="h-4 w-4 animate-spin" /> : <>I've paid — submit for verification <ArrowRight className="h-4 w-4" /></>}
              </span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function Stepper({ step }: { step: 1 | 2 | 3 }) {
  const items = [
    { n: 1, label: "Details", icon: User },
    { n: 2, label: "Payment", icon: CreditCard },
    { n: 3, label: "Verification", icon: ShieldCheck },
  ];
  return (
    <div className="flex items-center justify-center gap-2 md:gap-6">
      {items.map((it, i) => (
        <div key={it.n} className="flex items-center gap-2 md:gap-6">
          <div className="flex flex-col items-center gap-2">
            <div className={cn(
              "grid h-12 w-12 place-items-center rounded-full font-semibold transition-all",
              step >= it.n ? "bg-gradient-primary text-primary-foreground shadow-glow-primary" : "bg-accent text-muted-foreground"
            )}>
              <it.icon className="h-5 w-5" />
            </div>
            <div className={cn("text-xs font-medium", step >= it.n ? "text-foreground" : "text-muted-foreground")}>{it.label}</div>
          </div>
          {i < items.length - 1 && (
            <div className={cn("h-px w-10 md:w-24 transition", step > it.n ? "bg-gradient-primary" : "bg-border")} />
          )}
        </div>
      ))}
    </div>
  );
}

function Field({ label, error, children, className }: { label: string; error?: string; children: React.ReactNode; className?: string }) {
  return (
    <label className={cn("block", className)}>
      <span className="text-sm font-medium">{label}</span>
      <div className="mt-1.5">{children}</div>
      {error && <p className="mt-1 text-xs text-destructive">{error}</p>}
    </label>
  );
}

function InfoRow({ label, value, onCopy, copied }: { label: string; value: string; onCopy?: () => void; copied?: boolean }) {
  return (
    <div className="flex items-center justify-between rounded-xl bg-accent/50 px-4 py-3">
      <div>
        <div className="text-xs text-muted-foreground">{label}</div>
        <div className="font-mono text-sm font-semibold">{value}</div>
      </div>
      {onCopy && (
        <button onClick={onCopy} className="p-2 rounded-lg hover:bg-card transition">
          {copied ? <Check className="h-4 w-4 text-success" /> : <Copy className="h-4 w-4" />}
        </button>
      )}
    </div>
  );
}
