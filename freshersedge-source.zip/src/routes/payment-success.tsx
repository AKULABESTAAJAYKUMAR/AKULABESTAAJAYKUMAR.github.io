import { createFileRoute, Link } from "@tanstack/react-router";
import { z } from "zod";
import { useEffect, useState } from "react";
import { CheckCircle2, Clock, XCircle, MessageCircle, Home } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/payment-success")({
  validateSearch: z.object({ ref: z.string() }),
  head: () => ({
    meta: [
      { title: "Payment Submitted — FreshersEdge" },
      { name: "description", content: "Your payment reference has been submitted and is under verification." },
      { property: "og:title", content: "Payment Submitted — FreshersEdge" },
      { property: "og:description", content: "Your payment reference is under verification." },
    ],
  }),
  component: SuccessPage,
});

type Payment = {
  reference_number: string;
  status: string;
  amount: number;
  full_name: string;
  service_type: string;
};

function SuccessPage() {
  const { ref } = Route.useSearch();
  const [payment, setPayment] = useState<Payment | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    async function load() {
      const { data } = await supabase
        .from("payments")
        .select("reference_number, status, amount, full_name, service_type")
        .eq("reference_number", ref)
        .maybeSingle();
      if (mounted) { setPayment(data as Payment | null); setLoading(false); }
    }
    load();
    const t = setInterval(load, 8000);
    return () => { mounted = false; clearInterval(t); };
  }, [ref]);

  const status = payment?.status ?? "pending";
  const statusMeta = {
    pending: { icon: Clock, label: "Pending Verification", color: "text-warning", bg: "bg-warning/10", ring: "ring-warning/30" },
    verified: { icon: CheckCircle2, label: "Verified", color: "text-success", bg: "bg-success/10", ring: "ring-success/30" },
    rejected: { icon: XCircle, label: "Rejected", color: "text-destructive", bg: "bg-destructive/10", ring: "ring-destructive/30" },
  }[status] ?? { icon: Clock, label: status, color: "text-muted-foreground", bg: "bg-accent", ring: "ring-border" };
  const Icon = statusMeta.icon;

  return (
    <div className="mx-auto max-w-2xl px-4 sm:px-6 lg:px-8 py-16">
      <div className="rounded-3xl border bg-card shadow-premium p-8 md:p-10 text-center">
        <div className={cn("mx-auto grid h-20 w-20 place-items-center rounded-full ring-8", statusMeta.bg, statusMeta.ring)}>
          <Icon className={cn("h-10 w-10", statusMeta.color)} />
        </div>
        <h1 className="mt-6 text-3xl font-bold">Payment submitted</h1>
        <p className="mt-2 text-muted-foreground">Thank you{payment ? `, ${payment.full_name.split(" ")[0]}` : ""}. Your request is being processed.</p>

        <div className="mt-8 rounded-2xl bg-accent/40 border p-6 space-y-3 text-left">
          <Row label="Reference number" value={ref} mono />
          {payment && <>
            <Row label="Service" value={payment.service_type} />
            <Row label="Amount" value={`₹${Number(payment.amount).toFixed(2)}`} />
          </>}
          <Row label="Status" value={<span className={cn("font-semibold", statusMeta.color)}>{statusMeta.label}</span>} />
        </div>

        <p className="mt-6 text-sm text-muted-foreground">
          We'll message you on WhatsApp as soon as your payment is verified — usually within 5–15 minutes.
        </p>

        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <a href="https://wa.me/917448737207" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full bg-gradient-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-elegant">
            <MessageCircle className="h-4 w-4" /> Message on WhatsApp
          </a>
          <Link to="/" className="inline-flex items-center gap-2 rounded-full border bg-card px-6 py-3 text-sm font-semibold hover:bg-accent">
            <Home className="h-4 w-4" /> Home
          </Link>
        </div>
        {loading && <p className="mt-4 text-xs text-muted-foreground">Checking latest status…</p>}
      </div>
    </div>
  );
}

function Row({ label, value, mono }: { label: string; value: React.ReactNode; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm text-muted-foreground">{label}</span>
      <span className={cn("text-sm font-medium", mono && "font-mono")}>{value}</span>
    </div>
  );
}
