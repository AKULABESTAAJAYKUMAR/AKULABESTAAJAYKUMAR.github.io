import { createFileRoute, Link } from "@tanstack/react-router";
import {
  BookOpen, Briefcase, Code2, ListChecks, Rocket, FileText,
  Zap, Users, ShieldCheck, Clock, Star, ArrowRight, CheckCircle2, MessageCircle,
} from "lucide-react";
import { useState } from "react";
import heroImg from "@/assets/hero-students.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FreshersEdge — Exam & Interview Assistance for Freshers" },
      { name: "description", content: "Ace your placement journey with trusted support for exams, coding rounds, interviews and resume preparation. 1000+ students assisted." },
      { property: "og:title", content: "FreshersEdge — Exam & Interview Assistance for Freshers" },
      { property: "og:description", content: "Ace your placement journey with trusted support for exams, coding rounds, interviews and resume preparation. 1000+ students assisted." },
    ],
  }),
  component: HomePage,
});

const services = [
  { icon: BookOpen, title: "Exam Support", desc: "Real-time guidance during online exams and mock tests." },
  { icon: Briefcase, title: "Interview Support", desc: "HR + technical rounds with confidence and clarity." },
  { icon: Code2, title: "Coding Assistance", desc: "DSA, OOPs, SQL — live help during coding rounds." },
  { icon: ListChecks, title: "MCQ Guidance", desc: "Aptitude, reasoning and technical MCQs solved fast." },
  { icon: Rocket, title: "Placement Preparation", desc: "End-to-end preparation from resume to offer." },
  { icon: FileText, title: "Resume Guidance", desc: "ATS-ready resumes crafted for freshers." },
];

const why = [
  { icon: Zap, title: "Fast Support", desc: "Response within minutes, round the clock." },
  { icon: Users, title: "Experienced Guidance", desc: "Mentors from top product companies." },
  { icon: ShieldCheck, title: "Simple Payment", desc: "Direct UPI, instant confirmation." },
  { icon: Star, title: "Trusted by Students", desc: "1000+ freshers placed and assisted." },
  { icon: Clock, title: "Professional Assistance", desc: "Serious, structured, on-time help." },
];

const testimonials = [
  { name: "Ananya S.", role: "CSE, VIT", quote: "Cleared my TCS interview on the first try. The mock sessions were incredibly close to the real thing." },
  { name: "Rahul K.", role: "IT, JNTU", quote: "Fast responses, real coding help. I finally understood how to approach DSA questions in interviews." },
  { name: "Priya M.", role: "ECE, SRM", quote: "The resume they built got me shortlisted at 4 companies in a week. Worth every rupee." },
];

const faqs = [
  { q: "How quickly do you respond?", a: "Within a few minutes on WhatsApp, 24×7. Urgent exam requests are prioritised instantly." },
  { q: "Which services are covered?", a: "Exams, coding rounds, aptitude, technical/HR interviews, resume writing and placement preparation." },
  { q: "How does payment work?", a: "You pay directly via UPI (GPay, PhonePe, Paytm, BHIM). No card details, no third parties." },
  { q: "Is my data safe?", a: "Yes. We only collect the details necessary to deliver the service and never share them." },
  { q: "Do you offer refunds?", a: "Refunds are handled case-by-case as detailed in our Refund Policy." },
];

function HomePage() {
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-gradient-soft" />
        <div className="absolute inset-0 -z-10" style={{ backgroundImage: "var(--gradient-glow)" }} />
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-16 pb-20 lg:pt-24 lg:pb-28">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-up">
              <div className="inline-flex items-center gap-2 rounded-full bg-accent px-3 py-1 text-xs font-medium text-accent-foreground">
                <span className="h-2 w-2 rounded-full bg-success animate-pulse" /> 24×7 live support · trusted since 2022
              </div>
              <h1 className="mt-5 text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.05]">
                Ace Your <span className="text-gradient-primary">Placement</span> Journey
              </h1>
              <p className="mt-5 text-lg text-muted-foreground max-w-xl">
                Trusted support for exams, coding rounds, technical interviews and placement preparation — delivered by mentors who've been there.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link to="/exam-assistance" className="inline-flex items-center gap-2 rounded-full bg-gradient-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-elegant hover:shadow-premium transition">
                  Exam Assistance <ArrowRight className="h-4 w-4" />
                </Link>
                <Link to="/interview-assistance" className="inline-flex items-center gap-2 rounded-full border bg-card px-6 py-3 text-sm font-semibold hover:bg-accent transition">
                  Interview Assistance
                </Link>
                <Link to="/payment" className="inline-flex items-center gap-2 rounded-full border-2 border-primary px-6 py-3 text-sm font-semibold text-primary hover:bg-primary hover:text-primary-foreground transition">
                  Make Payment
                </Link>
              </div>
              <dl className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-4">
                {[
                  ["1000+", "Students Assisted"],
                  ["24×7", "Support"],
                  ["<5 min", "Fast Response"],
                  ["100%", "Trusted Guidance"],
                ].map(([k, v]) => (
                  <div key={v} className="rounded-2xl border bg-card p-4 shadow-sm">
                    <dt className="text-2xl font-bold text-gradient-primary">{k}</dt>
                    <dd className="mt-1 text-xs text-muted-foreground">{v}</dd>
                  </div>
                ))}
              </dl>
            </div>
            <div className="relative">
              <div className="absolute -inset-6 -z-10 rounded-[2rem] bg-gradient-primary opacity-20 blur-3xl" />
              <div className="relative overflow-hidden rounded-[2rem] shadow-premium border">
                <img src={heroImg} alt="Students preparing for placements" width={1600} height={1200} className="w-full h-auto object-cover" />
              </div>
              <div className="hidden md:flex absolute -bottom-6 -left-6 glass rounded-2xl p-4 shadow-elegant animate-float">
                <CheckCircle2 className="h-8 w-8 text-success" />
                <div className="ml-3">
                  <div className="text-sm font-semibold">Verified Mentors</div>
                  <div className="text-xs text-muted-foreground">Product-company experience</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20">
        <SectionHeader eyebrow="Services" title="Everything you need to land the offer" desc="Six focused services designed around what freshers actually struggle with." />
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {services.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="group relative rounded-3xl border bg-card p-6 shadow-sm hover:shadow-premium hover:-translate-y-1 transition-all duration-300">
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-primary text-primary-foreground shadow-glow-primary group-hover:scale-110 transition-transform">
                <Icon className="h-6 w-6" />
              </div>
              <h3 className="mt-4 text-lg font-semibold">{title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{desc}</p>
              <div className="absolute inset-x-6 bottom-0 h-px bg-gradient-primary opacity-0 group-hover:opacity-100 transition" />
            </div>
          ))}
        </div>
      </section>

      {/* WHY US */}
      <section className="bg-gradient-soft py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeader eyebrow="Why FreshersEdge" title="Real help, no fluff" desc="Built by placement veterans for students who need results, not pep talks." />
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
            {why.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="rounded-2xl bg-card p-5 border shadow-sm hover:shadow-md transition">
                <Icon className="h-8 w-8 text-primary" />
                <h4 className="mt-3 font-semibold">{title}</h4>
                <p className="mt-1 text-xs text-muted-foreground">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20">
        <SectionHeader eyebrow="Testimonials" title="Loved by freshers across India" desc="A few words from students who've used FreshersEdge." />
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {testimonials.map((t) => (
            <div key={t.name} className="rounded-3xl border bg-card p-6 shadow-sm hover:shadow-elegant transition">
              <div className="flex text-warning">{"★★★★★".split("").map((s, i) => <span key={i}>{s}</span>)}</div>
              <p className="mt-4 text-sm leading-relaxed">"{t.quote}"</p>
              <div className="mt-6 flex items-center gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-full bg-gradient-primary text-primary-foreground font-semibold">{t.name.charAt(0)}</div>
                <div>
                  <div className="text-sm font-semibold">{t.name}</div>
                  <div className="text-xs text-muted-foreground">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-gradient-soft py-20">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
          <SectionHeader eyebrow="FAQ" title="Frequently asked questions" desc="Quick answers. If you need more, message us on WhatsApp." />
          <div className="mt-10 space-y-3">
            {faqs.map((f, i) => <FaqItem key={i} {...f} />)}
          </div>
        </div>
      </section>

      {/* CONTACT CTA */}
      <section id="contact" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-hero p-10 md:p-16 text-primary-foreground shadow-premium">
          <div className="relative z-10 grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold">Ready when you are.</h2>
              <p className="mt-3 text-primary-foreground/90 max-w-md">Message us on WhatsApp for an instant reply, or start your payment now.</p>
            </div>
            <div className="flex flex-wrap gap-3 md:justify-end">
              <a href="https://wa.me/917448737207" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full bg-card px-6 py-3 text-sm font-semibold text-foreground shadow-elegant hover:scale-105 transition">
                <MessageCircle className="h-4 w-4" /> Chat on WhatsApp
              </a>
              <Link to="/payment" className="inline-flex items-center gap-2 rounded-full bg-foreground/10 border border-primary-foreground/30 px-6 py-3 text-sm font-semibold hover:bg-foreground/20 transition">
                Make Payment
              </Link>
            </div>
          </div>
          <div className="absolute -right-24 -top-24 h-96 w-96 rounded-full bg-white/10 blur-3xl" />
        </div>
      </section>
    </>
  );
}

function SectionHeader({ eyebrow, title, desc }: { eyebrow: string; title: string; desc: string }) {
  return (
    <div className="max-w-2xl mx-auto text-center">
      <div className="inline-block text-xs font-semibold uppercase tracking-wider text-primary">{eyebrow}</div>
      <h2 className="mt-2 text-3xl md:text-4xl font-bold">{title}</h2>
      <p className="mt-3 text-muted-foreground">{desc}</p>
    </div>
  );
}

function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-2xl border bg-card overflow-hidden">
      <button onClick={() => setOpen((v) => !v)} className="w-full flex items-center justify-between p-5 text-left hover:bg-accent/50 transition">
        <span className="font-medium">{q}</span>
        <span className={`text-primary transition-transform ${open ? "rotate-45" : ""}`}>+</span>
      </button>
      <div className={`grid transition-all ${open ? "grid-rows-[1fr]" : "grid-rows-[0fr]"}`}>
        <div className="overflow-hidden">
          <p className="px-5 pb-5 text-sm text-muted-foreground">{a}</p>
        </div>
      </div>
    </div>
  );
}
